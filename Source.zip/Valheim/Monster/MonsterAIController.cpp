// Fill out your copyright notice in the Description page of Project Settings.


#include "Monster/MonsterAIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include <BehaviorTree/BehaviorTreeComponent.h>

AMonsterAIController::AMonsterAIController()
{
    // Perception Component ����
    AIPerception = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerception"));

    // Sight Config ����
    SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));
    SightConfig->SightRadius = 500;          // �þ� ����
    SightConfig->LoseSightRadius = 600;       // �Ҵ� ����    
    SightConfig->PeripheralVisionAngleDegrees = 100; // �þ߰�
    SightConfig->SetMaxAge(2.f);                 // ��� ���� �ð�
    SightConfig->DetectionByAffiliation.bDetectEnemies = true;
    SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
    SightConfig->DetectionByAffiliation.bDetectFriendlies = true;

    // Perception�� Sight ���
    AIPerception->ConfigureSense(*SightConfig);
    AIPerception->SetDominantSense(SightConfig->GetSenseImplementation());

    // ���� �ݹ� ���ε�
    AIPerception->OnTargetPerceptionUpdated.AddDynamic(this, &AMonsterAIController::OnTargetPerceptionUpdated);
}

void AMonsterAIController::OnPossess(APawn* InPawn)
{
    Super::OnPossess(InPawn);
	
    RunBehaviorTree(BT);
}

void AMonsterAIController::OnTargetPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{

}

void AMonsterAIController::StopAI()
{
    //StopTree(EBTStopMode::Safe);
    //CleanupBrainComponent();

    UBehaviorTreeComponent* BTC = Cast<UBehaviorTreeComponent>(GetBrainComponent());
    if (nullptr == BTC)
    {
        return;
    }
    UE_LOG(LogTemp, Warning, TEXT("StopTree"));
    BTC->StopTree(EBTStopMode::Safe);
}
