// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/Interactable.h"

// Add default functionality here for any IInteractable functions that are not pure virtual.

void IInteractable::Interact(APawn* Interactor)
{
}
